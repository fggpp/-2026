import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import psycopg2
import hashlib
import secrets
import hmac
import time
import random

# ---------- НАСТРОЙКИ БАЗЫ ДАННЫХ ----------
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "dbname": "production_db",
    "user": "postgres",
    # Замени значение ниже на пароль пользователя postgres.
    "password": "yaeball",
}

MAX_ATTEMPTS = 3
LOCK_SECONDS = 30


def connect_db():
    return psycopg2.connect(**DB_CONFIG)


# ---------- ПАРОЛИ ----------
def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    hashed = hashlib.pbkdf2_hmac(
        "sha256", password.encode(), salt.encode(), 200_000
    ).hex()
    return salt, hashed


def verify_password(password, salt, expected_hash):
    _, actual_hash = hash_password(password, salt)
    return hmac.compare_digest(actual_hash, expected_hash)


# ---------- ПОДГОТОВКА БД ----------
def init_db():
    with connect_db() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS app_users (
                    user_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                    username VARCHAR(50) UNIQUE NOT NULL,
                    password_salt TEXT NOT NULL,
                    password_hash TEXT NOT NULL,
                    role VARCHAR(10) NOT NULL
                        CHECK (role IN ('Admin', 'User')),
                    is_active BOOLEAN NOT NULL DEFAULT TRUE
                );
            """)

            cur.execute("SELECT COUNT(*) FROM app_users;")
            count = cur.fetchone()[0]

            if count == 0:
                for username, password, role in [
                    ("admin", "Admin123!", "Admin"),
                    ("user", "User123!", "User"),
                ]:
                    salt, hashed = hash_password(password)
                    cur.execute("""
                        INSERT INTO app_users
                            (username, password_salt, password_hash, role)
                        VALUES (%s, %s, %s, %s);
                    """, (username, salt, hashed, role))


# ---------- ПАЗЛ-КАПЧА ----------
class PuzzleCaptcha(tk.Toplevel):
    SYMBOLS = ["★", "●", "▲", "◆", "♥", "■", "✿", "☀", "⬟"]

    def __init__(self, parent, callback):
        super().__init__(parent)
        self.title("Пазл-капча")
        self.resizable(False, False)
        self.callback = callback
        self.sequence = random.sample(self.SYMBOLS, 3)
        self.position = 0
        self.buttons = []

        ttk.Label(
            self,
            text="Нажми символы в указанном порядке:",
            padding=10
        ).pack()

        ttk.Label(
            self,
            text="  →  ".join(self.sequence),
            font=("Arial", 16, "bold")
        ).pack(pady=5)

        grid = ttk.Frame(self, padding=10)
        grid.pack()

        shuffled = self.SYMBOLS.copy()
        random.shuffle(shuffled)

        for i, symbol in enumerate(shuffled):
            btn = ttk.Button(
                grid,
                text=symbol,
                width=5,
                command=lambda s=symbol: self.choose(s)
            )
            btn.grid(row=i // 3, column=i % 3, padx=3, pady=3)
            self.buttons.append(btn)

        self.result = ttk.Label(self, text="")
        self.result.pack(pady=5)

        self.transient(parent)
        self.grab_set()

    def choose(self, symbol):
        if symbol != self.sequence[self.position]:
            self.result.config(text="Неверно. Попробуй ещё раз.")
            self.position = 0
            return

        self.position += 1

        if self.position == len(self.sequence):
            self.destroy()
            self.callback(True)


# ---------- ОКНО АВТОРИЗАЦИИ ----------
class LoginApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Система управления производством")
        self.root.geometry("420x330")
        self.root.resizable(False, False)

        self.failed_attempts = 0
        self.lock_until = 0
        self.captcha_required = False

        ttk.Label(
            root,
            text="Вход в систему",
            font=("Arial", 18, "bold")
        ).pack(pady=20)

        form = ttk.Frame(root, padding=15)
        form.pack(fill="x")

        ttk.Label(form, text="Логин:").grid(
            row=0, column=0, sticky="w", pady=5
        )
        self.username = ttk.Entry(form, width=28)
        self.username.grid(row=0, column=1, pady=5)

        ttk.Label(form, text="Пароль:").grid(
            row=1, column=0, sticky="w", pady=5
        )
        self.password = ttk.Entry(form, show="*", width=28)
        self.password.grid(row=1, column=1, pady=5)
        self.password.bind("<Return>", lambda event: self.login())

        self.status = ttk.Label(root, text="")
        self.status.pack(pady=5)

        ttk.Button(
            root, text="Войти", command=self.login
        ).pack(pady=10)

    def login(self):
        if time.time() < self.lock_until:
            remaining = int(self.lock_until - time.time()) + 1
            messagebox.showwarning(
                "Блокировка",
                f"Вход заблокирован. Подожди {remaining} сек."
            )
            return

        username = self.username.get().strip()
        password = self.password.get()

        if not username or not password:
            messagebox.showwarning(
                "Вход", "Введи логин и пароль."
            )
            return

        try:
            with connect_db() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        SELECT user_id, username, password_salt,
                               password_hash, role, is_active
                        FROM app_users
                        WHERE username = %s;
                    """, (username,))
                    user = cur.fetchone()
        except Exception as error:
            messagebox.showerror(
                "Ошибка БД",
                f"Не удалось подключиться к PostgreSQL.\n{error}"
            )
            return

        valid = (
            user is not None
            and user[5]
            and verify_password(password, user[2], user[3])
        )

        if not valid:
            self.failed_attempts += 1
            self.password.delete(0, tk.END)

            if self.failed_attempts >= MAX_ATTEMPTS:
                self.lock_until = time.time() + LOCK_SECONDS
                self.status.config(text="Вход временно заблокирован.")
                messagebox.showerror(
                    "Блокировка",
                    "Три неудачные попытки. Подожди 30 секунд."
                )
                self.failed_attempts = 0
                return

            self.status.config(text="Неверный логин или пароль.")

            if not self.captcha_required:
                self.captcha_required = True
                PuzzleCaptcha(self.root, self.captcha_done)
            else:
                messagebox.showwarning(
                    "Ошибка входа",
                    f"Осталось попыток: "
                    f"{MAX_ATTEMPTS - self.failed_attempts}"
                )
            return

        if self.captcha_required:
            self.status.config(
                text="Пройди капчу перед повторной попыткой."
            )
            PuzzleCaptcha(self.root, self.captcha_done)
            return

        self.failed_attempts = 0
        self.open_dashboard(user[1], user[4])

    def captcha_done(self, success):
        if success:
            self.captcha_required = False
            self.status.config(
                text="Капча пройдена. Теперь можно войти."
            )

    def open_dashboard(self, username, role):
        self.root.withdraw()
        Dashboard(self.root, username, role)


# ---------- ГЛАВНОЕ ОКНО ----------
class Dashboard(tk.Toplevel):
    def __init__(self, root, username, role):
        super().__init__(root)
        self.root = root
        self.username = username
        self.role = role

        self.title(f"Производство — {username} ({role})")
        self.geometry("950x600")
        self.protocol("WM_DELETE_WINDOW", self.logout)

        header = ttk.Frame(self, padding=10)
        header.pack(fill="x")

        ttk.Label(
            header,
            text=f"Пользователь: {username} | Роль: {role}",
            font=("Arial", 12, "bold")
        ).pack(side="left")

        ttk.Button(
            header, text="Выйти", command=self.logout
        ).pack(side="right")

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=10, pady=10)

        self.data_tab = ttk.Frame(self.tabs)
        self.tabs.add(self.data_tab, text="Данные производства")

        if role == "Admin":
            self.admin_tab = ttk.Frame(self.tabs)
            self.tabs.add(self.admin_tab, text="Администрирование")
            self.build_admin_tab()

        self.build_data_tab()

    def build_data_tab(self):
        controls = ttk.Frame(self.data_tab, padding=10)
        controls.pack(fill="x")

        self.data_choice = ttk.Combobox(
            controls,
            values=[
                "Заказчики",
                "Материалы",
                "Товары",
                "Заказы",
                "Стоимость материалов",
            ],
            state="readonly",
            width=28
        )
        self.data_choice.current(0)
        self.data_choice.pack(side="left", padx=5)

        ttk.Button(
            controls,
            text="Показать",
            command=self.show_data
        ).pack(side="left")

        self.table = ttk.Treeview(
            self.data_tab, show="headings"
        )
        self.table.pack(fill="both", expand=True, padx=10, pady=10)

    def show_data(self):
        queries = {
            "Заказчики": """
                SELECT customer_id, full_name, phone, email
                FROM customers ORDER BY customer_id;
            """,
            "Материалы": """
                SELECT material_id, material_name, unit, price_per_unit
                FROM materials ORDER BY material_id;
            """,
            "Товары": """
                SELECT product_id, product_name
                FROM products ORDER BY product_id;
            """,
            "Заказы": """
                SELECT o.order_id, c.full_name, o.order_date
                FROM orders o
                JOIN customers c ON c.customer_id = o.customer_id
                ORDER BY o.order_id;
            """,
            "Стоимость материалов": """
                SELECT o.order_id, c.full_name, p.product_name,
                       m.material_name,
                       oi.quantity * pm.quantity_per_product
                           AS material_quantity,
                       m.unit,
                       oi.quantity * pm.quantity_per_product
                           * m.price_per_unit AS material_cost
                FROM orders o
                JOIN customers c ON c.customer_id = o.customer_id
                JOIN order_items oi ON oi.order_id = o.order_id
                JOIN products p ON p.product_id = oi.product_id
                JOIN product_materials pm ON pm.product_id = p.product_id
                JOIN materials m ON m.material_id = pm.material_id
                ORDER BY o.order_id, p.product_name, m.material_name;
            """
        }

        try:
            with connect_db() as conn:
                with conn.cursor() as cur:
                    cur.execute(queries[self.data_choice.get()])
                    columns = [desc[0] for desc in cur.description]
                    rows = cur.fetchall()
        except Exception as error:
            messagebox.showerror("Ошибка", str(error))
            return

        self.table.delete(*self.table.get_children())
        self.table["columns"] = columns

        for col in columns:
            self.table.heading(col, text=col)
            self.table.column(col, width=130, anchor="w")

        for row in rows:
            self.table.insert("", tk.END, values=row)

    def build_admin_tab(self):
        frame = self.admin_tab

        ttk.Label(
            frame,
            text="Управление пользователями",
            font=("Arial", 14, "bold")
        ).pack(pady=10)

        self.user_table = ttk.Treeview(
            frame,
            columns=("id", "username", "role", "active"),
            show="headings"
        )
        for col, title in [
            ("id", "ID"),
            ("username", "Логин"),
            ("role", "Роль"),
            ("active", "Активен"),
        ]:
            self.user_table.heading(col, text=title)
            self.user_table.column(col, width=150)

        self.user_table.pack(fill="both", expand=True, padx=10, pady=10)

        buttons = ttk.Frame(frame)
        buttons.pack(pady=10)

        ttk.Button(
            buttons,
            text="Обновить список",
            command=self.refresh_users
        ).pack(side="left", padx=5)

        ttk.Button(
            buttons,
            text="Добавить пользователя",
            command=self.add_user
        ).pack(side="left", padx=5)

        ttk.Button(
            buttons,
            text="Включить/отключить",
            command=self.toggle_user
        ).pack(side="left", padx=5)

        self.refresh_users()

    def refresh_users(self):
        try:
            with connect_db() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        SELECT user_id, username, role, is_active
                        FROM app_users ORDER BY user_id;
                    """)
                    rows = cur.fetchall()
        except Exception as error:
            messagebox.showerror("Ошибка", str(error))
            return

        self.user_table.delete(*self.user_table.get_children())
        for row in rows:
            self.user_table.insert("", tk.END, values=row)

    def add_user(self):
        username = simpledialog.askstring(
            "Новый пользователь", "Логин:", parent=self
        )
        if not username:
            return

        password = simpledialog.askstring(
            "Новый пользователь", "Пароль:", show="*", parent=self
        )
        if not password:
            return

        role = simpledialog.askstring(
            "Роль", "Введи Admin или User:", parent=self
        )
        if role not in ("Admin", "User"):
            messagebox.showwarning(
                "Ошибка", "Роль должна быть Admin или User."
            )
            return

        salt, hashed = hash_password(password)

        try:
            with connect_db() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        INSERT INTO app_users
                            (username, password_salt, password_hash, role)
                        VALUES (%s, %s, %s, %s);
                    """, (username.strip(), salt, hashed, role))
        except Exception as error:
            messagebox.showerror("Ошибка", str(error))
            return

        self.refresh_users()
        messagebox.showinfo("Готово", "Пользователь добавлен.")

    def toggle_user(self):
        selected = self.user_table.selection()
        if not selected:
            messagebox.showwarning(
                "Выбор", "Сначала выбери пользователя."
            )
            return

        values = self.user_table.item(selected[0], "values")
        user_id, username, role, active = values

        if username == self.username:
            messagebox.showwarning(
                "Запрещено", "Нельзя отключить собственную учётную запись."
            )
            return

        new_active = not (str(active).lower() == "true")

        try:
            with connect_db() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        UPDATE app_users
                        SET is_active = %s
                        WHERE user_id = %s;
                    """, (new_active, user_id))
        except Exception as error:
            messagebox.showerror("Ошибка", str(error))
            return

        self.refresh_users()

    def logout(self):
        self.destroy()
        self.root.deiconify()


if __name__ == "__main__":
    try:
        init_db()
    except Exception as error:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "Ошибка подключения",
            "Не удалось подготовить базу данных.\n\n"
            f"{error}\n\n"
            "Проверь настройки DB_CONFIG в main.py."
        )
        root.destroy()
        raise SystemExit(1)

    root = tk.Tk()
    app = LoginApp(root)
    root.mainloop()
