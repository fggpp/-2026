# ProductionApp

1. Установка зависимости
Откройте терминал VS Code в этой папке и выполните:

```bash
python -m pip install -r requirements.txt
```
2. Запуск
```bash
python main.py
```

3. Тестовые учётные записи
- Администратор: `admin` / `Admin123!`
- Пользователь: `user` / `User123!`


